## Class

- Program
  - ConnectionWifi
  - DepotJson
  - ServerWeb
  - DonneeCompacteur

- Compacteur
  - LCD1602
  - LCD1602Proxy
  - LCD1602ProxyI2C
  - Affichage4Digits
  - Affichage4DigitsProxy
  - Affichage4DigitsProxyTM1637
  - Bouton
  - DetecteurDistance
  - LED

## Etats

- Fonction
- Entretien
