# TP02 - Compacteur de cannettes - documentation

Mettez votre rapport finale de TP ici.
