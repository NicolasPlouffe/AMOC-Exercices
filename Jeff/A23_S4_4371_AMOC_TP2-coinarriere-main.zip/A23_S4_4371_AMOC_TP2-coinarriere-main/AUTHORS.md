# TP02 - Compacteur de cannettes

## Auteurs du TP

- Bryen Savard 0135450
- Jeff Hebert 1932794

## Lien de la vidéo de présentation

- Lien YouTube #1 : https://youtu.be/lS3BYUwbSsY
- Lien YouTube #2 (si applicable) :
