## Classes
    -WifiManagerPerso
    -ElementChauffant   (relais)
    -Photoresistance   
    -GestionPlante      (orchestrateur)
    -Bme
    -CapteurHumiditeSol
    -PompeAEau
    -LED
    


## Données à afficher
    -Temperature actuel
    -Humidité actuel
    -Niveau eau actuel
    -Intensité lumineuse actuel

    -Moyenne heures de luminosité / jours
    
Utiliser Home assistant


## Presentation
    -15 min
    -Cas d'affaire (problème a résoudre)
    -Cout / Bénifice
    -Marché estimé
    -Fonctionnement pour Mme Michou 
    -Pub (30sec à 1min)
    -Démo

## Detecteur Humidité
    -utiliser un array pour valider l appareil 
        prendre mesure seulement quand on arrose
        si pas assez de variante, shutdown l'appareil