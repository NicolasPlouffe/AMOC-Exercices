# TP03 - Station météo

## Auteurs du TP

- Bryen Savard 0135450
- Jeff Hebert 1932794

## Lien dépôt du code source

- Lien du dépôt : 
https://github.com/DFC-Informatique-Cegep-de-Sainte-Foy/A23_S4_4371_AMOC_TP3-coin-arriere.git

## Lien de la vidéo de présentation

- Lien YouTube #1 : https://youtu.be/dJfRambJfWI
- Lien YouTube #2 (si applicable) :

## Pub :

- https://youtube.com/shorts/vhOWH-RWD1s?feature=share