const int dureeDELAllumeeLong = 1000;
const int dureeDELAllumeeCourt = 500;
const int dureeDELEteinte = 500;

#define DUREE_DEL_ALLUMEE 1000
#define DUREE_DEL_ETEINTE 500