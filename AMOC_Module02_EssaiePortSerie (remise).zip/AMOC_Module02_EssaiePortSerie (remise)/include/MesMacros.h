#define calculerMinimum (a,b) ((a)<(b)?(a):(b))
#define calculerMaximum (a,b) ((a)>(b)?(a):(b))