#pragma once    
#include "Arduino.h"


class Alphabet {

    public:
        Alphabet();
        void AfficherSEnMorse();
        void AfficherOEnMorse();
        void AfficherSOSEnMorse();
    };
