#pragma once
#include <Arduino.h>

// Connection Reseau


// Cegep

// #define WIFI_SSID "iot_lab"
// #define WIFI_PASSWORD "engagelejeuquejelegagne"

// Régions et fuseau horraire
#define TIMEZONECANADAEST "EST5EDT,M3.2.0/2,M11.1.0/2"


const int pinClk = 18;
const int pinData = 19;
