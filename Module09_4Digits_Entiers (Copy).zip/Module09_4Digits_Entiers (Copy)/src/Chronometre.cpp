#include "Chronometre.h"

Chronometre::Chronometre()
{
    this->compteur = 86340 ;
    this->dernierEnregistrement = millis();
    setTemps();


}

int Chronometre::getDizaineHeure()
{
    return dizaineHeure;
}

int Chronometre::getUniteHeure()
{
    return uniteHeure;
}

int Chronometre::getDizaineMinute() {
    return dizaineMinute;
}

int Chronometre::getUniteMinute() {
    return uniteMinute;
}

int Chronometre::getDizaineSeconde() {
    return dizaineSeconde;
}

int Chronometre::getUniteSeconde() {
    return uniteSeconde;
}

void Chronometre::setDizaineHeure(int p_valeur)
{
    this->dizaineHeure = p_valeur;
}

void Chronometre::setUniteHeure(int p_valeur)
{
    this->uniteHeure = p_valeur;
}

void Chronometre::setDizaineMinute(int d)
{
    dizaineMinute = d;
}
void Chronometre::setUniteMinute(int u)
{
    uniteMinute = u;
}
void Chronometre::setDizaineSeconde(int d)
{
    dizaineSeconde = d;
}
void Chronometre::setUniteSeconde(int u)
{
    uniteSeconde = u;
}


void Chronometre::Tick()
{
   unsigned long enregistrementCourrant = millis();
    unsigned long tempsEcoulee = enregistrementCourrant - dernierEnregistrement;

    if (tempsEcoulee >= 1000)
    {
        unsigned long  secondesEcoulees = tempsEcoulee/1000;
        compteur += secondesEcoulees;
        dernierEnregistrement += secondesEcoulees * 1000;

        if (compteur >= 86400) compteur %= 86400;

        setTemps();

    }
}

int Chronometre::getCompteur() const
{
    return compteur;
}

void Chronometre::setTemps() {
    unsigned long total = getCompteur(); // Récupère le compteur (ex: 86340)
    if (total >= 86400) total %= 86400; // Gestion du dépassement 24h

    int heures = total / 3600;
    int minutes = (total % 3600) / 60;
    int secondes = total % 60;

    // Décomposition des chiffres
    dizaineHeure = heures / 10;
    uniteHeure = heures % 10;
    dizaineMinute = minutes / 10;
    uniteMinute = minutes % 10;
    dizaineSeconde = secondes / 10;
    uniteSeconde = secondes % 10;
}



